//
//  WordPlayApp.swift
//  WordPlay
//
//  Created by Aishah Siraj on 10/18/23.
//

import SwiftUI

@main
struct WordPlayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
